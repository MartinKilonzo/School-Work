The script already takes girl.img as input.
To run the script file, please type:
%scriptfix asn2.script