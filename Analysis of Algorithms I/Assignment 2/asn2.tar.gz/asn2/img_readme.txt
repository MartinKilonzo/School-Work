File girl.img contains a 71 by 71 binary image 
in plain text.

In this file, a + means 1 and a space means 0.
We only consider the connected components of 1.

The total number of components is less than 26.
Therefore you can use letters from 'a' to 'z' to
identify all the components.

We use 4 connectivity for +.

Therefore ++ and + are considered connected.
                 +

However +  and  + are not considered connected.
         +     +
